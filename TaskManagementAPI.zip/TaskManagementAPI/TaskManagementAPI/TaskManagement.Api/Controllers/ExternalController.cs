﻿using Microsoft.AspNetCore.Mvc;
using TaskManagement.Application.Interfaces;

namespace TaskManagement.Api.Controllers;

[ApiController]
[Route("api/external")]
public class ExternalController : ControllerBase
{
    private readonly IExternalInfoService _external;

    public ExternalController(IExternalInfoService external)
    {
        _external = external;
    }

    [HttpGet("weather")]
    public async Task<IActionResult> GetWeather(CancellationToken ct)
    {
        var result = await _external.GetWeatherAsync(ct);
        return Ok(result);
    }
}
