﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagement.Application.DTOs;
using TaskManagement.Application.Interfaces;
using TaskManagement.Domain.Entities;

namespace TaskManagement.Application.Services;

public class TaskService : ITaskService
{
    private readonly ITaskRepository _repository;

    public TaskService(ITaskRepository repository)
    {
        _repository = repository;
    }

    public async Task<List<TaskReadDto>> GetAllAsync(CancellationToken ct)
    {
        var items = await _repository.GetAllAsync(ct);

        return items
            .Select(MapToReadDto)
            .ToList();
    }

    public async Task<TaskReadDto?> GetByIdAsync(Guid id, CancellationToken ct)
    {
        var item = await _repository.GetByIdAsync(id, ct);

        if (item == null)
            return null;

        return MapToReadDto(item);
    }

    public async Task<TaskReadDto> CreateAsync(TaskCreateDto dto, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(dto.Title))
            throw new ArgumentException("Title is required.");

        var entity = new TaskItem
        {
            Title = dto.Title.Trim(),
            Description = dto.Description?.Trim(),
            DueAtUtc = dto.DueAtUtc,
            IsCompleted = false
        };

        await _repository.AddAsync(entity, ct);

        return MapToReadDto(entity);
    }

    public async Task<bool> UpdateAsync(Guid id, TaskUpdateDto dto, CancellationToken ct)
    {
        var entity = await _repository.GetByIdAsync(id, ct);
        if (entity == null)
            return false;

        if (string.IsNullOrWhiteSpace(dto.Title))
            throw new ArgumentException("Title is required.");

        entity.Title = dto.Title.Trim();
        entity.Description = dto.Description?.Trim();
        entity.DueAtUtc = dto.DueAtUtc;
        entity.IsCompleted = dto.IsCompleted;
        entity.Touch();

        await _repository.UpdateAsync(entity, ct);
        return true;
    }

    public async Task<bool> DeleteAsync(Guid id, CancellationToken ct)
    {
        var entity = await _repository.GetByIdAsync(id, ct);
        if (entity == null)
            return false;

        await _repository.DeleteAsync(id, ct);
        return true;
    }

    public async Task<bool> CompleteAsync(Guid id, CancellationToken ct)
    {
        var entity = await _repository.GetByIdAsync(id, ct);
        if (entity == null)
            return false;

        entity.IsCompleted = true;
        entity.Touch();

        await _repository.UpdateAsync(entity, ct);
        return true;
    }

    private static TaskReadDto MapToReadDto(TaskItem item)
    {
        return new TaskReadDto(
            item.Id,
            item.Title,
            item.Description,
            item.DueAtUtc,
            item.IsCompleted,
            item.CreatedAtUtc,
            item.UpdatedAtUtc
        );
    }
}
