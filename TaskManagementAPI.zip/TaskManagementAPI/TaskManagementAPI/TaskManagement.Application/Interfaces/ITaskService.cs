﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagement.Application.DTOs;

namespace TaskManagement.Application.Interfaces;

public interface ITaskService
{
    Task<List<TaskReadDto>> GetAllAsync(CancellationToken ct);
    Task<TaskReadDto?> GetByIdAsync(Guid id, CancellationToken ct);
    Task<TaskReadDto> CreateAsync(TaskCreateDto dto, CancellationToken ct);
    Task<bool> UpdateAsync(Guid id, TaskUpdateDto dto, CancellationToken ct);
    Task<bool> DeleteAsync(Guid id, CancellationToken ct);
    Task<bool> CompleteAsync(Guid id, CancellationToken ct);
}
