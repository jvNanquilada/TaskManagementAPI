﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagement.Domain.Entities;

namespace TaskManagement.Application.Interfaces;

public interface ITaskRepository
{
    Task<List<TaskItem>> GetAllAsync(CancellationToken ct);
    Task<TaskItem?> GetByIdAsync(Guid id, CancellationToken ct);
    Task AddAsync(TaskItem item, CancellationToken ct);
    Task UpdateAsync(TaskItem item, CancellationToken ct);
    Task DeleteAsync(Guid id, CancellationToken ct);
    Task<List<TaskItem>> GetOverdueAsync(DateTime utcNow, CancellationToken ct);
}
