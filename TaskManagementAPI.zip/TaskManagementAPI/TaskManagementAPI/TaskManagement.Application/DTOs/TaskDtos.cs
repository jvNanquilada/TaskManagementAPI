﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskManagement.Application.DTOs;

public record TaskCreateDto(string Title, string? Description, DateTime? DueAtUtc);
public record TaskUpdateDto(string Title, string? Description, DateTime? DueAtUtc, bool IsCompleted);

public record TaskReadDto(
    Guid Id,
    string Title,
    string? Description,
    DateTime? DueAtUtc,
    bool IsCompleted,
    DateTime CreatedAtUtc,
    DateTime UpdatedAtUtc
);
