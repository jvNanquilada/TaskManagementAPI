﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http.Json;
using TaskManagement.Application.Interfaces;

namespace TaskManagement.Infrastructure.External;

public class OpenMeteoClient : IExternalInfoService
{
    private readonly HttpClient _http;

    public OpenMeteoClient(HttpClient http)
    {
        _http = http;
    }

    public async Task<object> GetWeatherAsync(CancellationToken ct)
    {
        var url = "v1/forecast?latitude=25.2048&longitude=55.2708&current=temperature_2m";

        try
        {
            using var response = await _http.GetAsync(url, ct);

            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync(ct);
                return new
                {
                    success = false,
                    statusCode = (int)response.StatusCode,
                    error = "External API call failed",
                    details = body.Length > 300 ? body[..300] : body
                };
            }

            var json = await response.Content.ReadFromJsonAsync<object>(cancellationToken: ct);
            return new
            {
                success = true,
                data = json
            };
        }
        catch (TaskCanceledException)
        {
            return new { success = false, error = "External API call timed out" };
        }
        catch (Exception ex)
        {
            return new { success = false, error = ex.Message };
        }
    }
}
