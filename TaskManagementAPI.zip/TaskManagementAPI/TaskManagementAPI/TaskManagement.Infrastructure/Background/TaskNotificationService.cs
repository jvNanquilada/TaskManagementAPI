﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using TaskManagement.Application.Interfaces;

namespace TaskManagement.Infrastructure.Background;

public class TaskNotificationService : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<TaskNotificationService> _logger;

    public TaskNotificationService(
        IServiceScopeFactory scopeFactory,
        ILogger<TaskNotificationService> logger)
    {
        _scopeFactory = scopeFactory;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("TaskNotificationService started");

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope = _scopeFactory.CreateScope();
                var repo = scope.ServiceProvider.GetRequiredService<ITaskRepository>();

                var overdueTasks = await repo.GetOverdueAsync(DateTime.UtcNow, stoppingToken);

                foreach (var task in overdueTasks)
                {
                    _logger.LogWarning(
                        "Task overdue: {Id} | {Title} | Due: {Due}",
                        task.Id,
                        task.Title,
                        task.DueAtUtc);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in TaskNotificationService");
            }

            await Task.Delay(TimeSpan.FromSeconds(30), stoppingToken);
        }
    }
}
