﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TaskManagement.Application.Interfaces;
using TaskManagement.Domain.Entities;
using TaskManagement.Infrastructure.Persistence;

namespace TaskManagement.Infrastructure.Repositories;

public class TaskRepository : ITaskRepository
{
    private readonly AppDbContext _db;

    public TaskRepository(AppDbContext db)
    {
        _db = db;
    }

    public Task<List<TaskItem>> GetAllAsync(CancellationToken ct)
    {
        return _db.Tasks
                  .OrderByDescending(x => x.CreatedAtUtc)
                  .ToListAsync(ct);
    }

    public Task<TaskItem?> GetByIdAsync(Guid id, CancellationToken ct)
    {
        return _db.Tasks.FirstOrDefaultAsync(x => x.Id == id, ct);
    }

    public async Task AddAsync(TaskItem item, CancellationToken ct)
    {
        _db.Tasks.Add(item);
        await _db.SaveChangesAsync(ct);
    }

    public async Task UpdateAsync(TaskItem item, CancellationToken ct)
    {
        _db.Tasks.Update(item);
        await _db.SaveChangesAsync(ct);
    }

    public async Task DeleteAsync(Guid id, CancellationToken ct)
    {
        var existing = await _db.Tasks.FirstAsync(x => x.Id == id, ct);
        _db.Tasks.Remove(existing);
        await _db.SaveChangesAsync(ct);
    }

    public Task<List<TaskItem>> GetOverdueAsync(DateTime utcNow, CancellationToken ct)
    {
        return _db.Tasks
                  .Where(x => !x.IsCompleted &&
                              x.DueAtUtc != null &&
                              x.DueAtUtc <= utcNow)
                  .OrderBy(x => x.DueAtUtc)
                  .ToListAsync(ct);
    }
}
